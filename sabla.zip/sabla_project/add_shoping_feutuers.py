import os
from pathlib import Path

def add_shopping_features():
    """اضافه کردن نام کاربر، سبد خرید و تسویه حساب"""
    
    project_path = Path("/home/ihsan/Desktop/sabla_project")
    os.chdir(project_path)
    
    print("🛒 اضافه کردن ویژگی‌های خرید...")
    
    # ۱. ایجاد مدل سبد خرید
    products_models_content = '''from django.db import models
from django.urls import reverse
from django.contrib.auth.models import User

class Category(models.Model):
    name = models.CharField(max_length=100, verbose_name="نام دسته‌بندی")
    description = models.TextField(blank=True, verbose_name="توضیحات")
    image = models.ImageField(upload_to='categories/', blank=True, null=True, verbose_name="تصویر")
    is_active = models.BooleanField(default=True, verbose_name="فعال")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاریخ ایجاد")
    
    class Meta:
        verbose_name = "دسته‌بندی"
        verbose_name_plural = "دسته‌بندی‌ها"
        ordering = ['name']
    
    def __str__(self):
        return self.name

class Product(models.Model):
    name = models.CharField(max_length=200, verbose_name="نام محصول")
    description = models.TextField(verbose_name="توضیحات")
    price = models.DecimalField(max_digits=10, decimal_places=0, verbose_name="قیمت (تومان)")
    discounted_price = models.DecimalField(max_digits=10, decimal_places=0, blank=True, null=True, verbose_name="قیمت تخفیف‌خورده")
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='products', verbose_name="دسته‌بندی")
    image = models.ImageField(upload_to='products/', blank=True, null=True, verbose_name="تصویر اصلی")
    is_organic = models.BooleanField(default=True, verbose_name="ارگانیک")
    is_available = models.BooleanField(default=True, verbose_name="موجود")
    stock = models.PositiveIntegerField(default=0, verbose_name="موجودی")
    origin = models.CharField(max_length=100, default="سیستان و بلوچستان", verbose_name="منطقه تولید")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاریخ ایجاد")
    
    class Meta:
        verbose_name = "محصول"
        verbose_name_plural = "محصولات"
        ordering = ['-created_at']
    
    def __str__(self):
        return self.name
    
    def get_absolute_url(self):
        return reverse('product_detail', args=[str(self.id)])
    
    @property
    def final_price(self):
        return self.discounted_price if self.discounted_price else self.price

class Cart(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='cart')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"سبد خرید {self.user.username}"
    
    @property
    def total_price(self):
        return sum(item.total_price for item in self.items.all())
    
    @property
    def total_items(self):
        return sum(item.quantity for item in self.items.all())

class CartItem(models.Model):
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    
    class Meta:
        unique_together = ['cart', 'product']
    
    def __str__(self):
        return f"{self.quantity} x {self.product.name}"
    
    @property
    def total_price(self):
        return self.quantity * self.product.final_price
'''
    
    with open("products/models.py", "w", encoding="utf-8") as f:
        f.write(products_models_content)
    print("✅ مدل سبد خرید ایجاد شد")
    
    # ۲. ایجاد viewهای سبد خرید
    products_views_content = '''from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.contrib import messages
from .models import Product, Category, Cart, CartItem

def home_view(request):
    featured_products = Product.objects.filter(
        is_available=True,
        discounted_price__isnull=False
    )[:4]
    
    new_products = Product.objects.filter(is_available=True)[:8]
    categories = Category.objects.filter(is_active=True)[:6]
    organic_products = Product.objects.filter(
        is_available=True, 
        is_organic=True
    )[:6]
    
    return render(request, 'products/home.html', {
        'site_name': 'سبلا',
        'description': 'فروشگاه محصولات ارگانیک سیستان و بلوچستان',
        'featured_products': featured_products,
        'new_products': new_products,
        'categories': categories,
        'organic_products': organic_products
    })

def product_list_view(request):
    products = Product.objects.filter(is_available=True)
    categories = Category.objects.filter(is_active=True)
    
    category_id = request.GET.get('category')
    if category_id:
        products = products.filter(category_id=category_id)
    
    return render(request, 'products/product_list.html', {
        'products': products,
        'categories': categories
    })

def product_detail_view(request, pk):
    product = get_object_or_404(Product, pk=pk, is_available=True)
    related_products = Product.objects.filter(
        category=product.category,
        is_available=True
    ).exclude(id=product.id)[:4]
    
    return render(request, 'products/product_detail.html', {
        'product': product,
        'related_products': related_products
    })

@login_required
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id, is_available=True)
    cart, created = Cart.objects.get_or_create(user=request.user)
    
    cart_item, created = CartItem.objects.get_or_create(
        cart=cart,
        product=product,
        defaults={'quantity': 1}
    )
    
    if not created:
        cart_item.quantity += 1
        cart_item.save()
    
    messages.success(request, f'{product.name} به سبد خرید اضافه شد')
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse({
            'success': True,
            'cart_total': cart.total_items,
            'message': f'{product.name} به سبد خرید اضافه شد'
        })
    
    return redirect('cart_view')

@login_required
def cart_view(request):
    cart = get_object_or_404(Cart, user=request.user)
    return render(request, 'products/cart.html', {'cart': cart})

@login_required
def update_cart_item(request, item_id):
    cart_item = get_object_or_404(CartItem, id=item_id, cart__user=request.user)
    
    if request.method == 'POST':
        action = request.POST.get('action')
        
        if action == 'increase':
            cart_item.quantity += 1
        elif action == 'decrease' and cart_item.quantity > 1:
            cart_item.quantity -= 1
        elif action == 'remove':
            cart_item.delete()
            messages.success(request, 'محصول از سبد خرید حذف شد')
            return redirect('cart_view')
        
        cart_item.save()
    
    return redirect('cart_view')

@login_required
def checkout_view(request):
    cart = get_object_or_404(Cart, user=request.user)
    
    if cart.total_items == 0:
        messages.warning(request, 'سبد خرید شما خالی است')
        return redirect('cart_view')
    
    return render(request, 'products/checkout.html', {
        'cart': cart,
        'user': request.user
    })
'''
    
    with open("products/views.py", "w", encoding="utf-8") as f:
        f.write(products_views_content)
    print("✅ viewهای سبد خرید ایجاد شدند")
    
    # ۳. اضافه کردن URLهای جدید
    products_urls_content = '''from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_view, name='home'),
    path('products/', views.product_list_view, name='product_list'),
    path('products/<int:pk>/', views.product_detail_view, name='product_detail'),
    path('cart/add/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
    path('cart/', views.cart_view, name='cart_view'),
    path('cart/update/<int:item_id>/', views.update_cart_item, name='update_cart_item'),
    path('checkout/', views.checkout_view, name='checkout'),
]
'''
    
    with open("products/urls.py", "w", encoding="utf-8") as f:
        f.write(products_urls_content)
    print("✅ URLهای سبد خرید اضافه شدند")
    
    # ۴. به‌روزرسانی هدر با نام کاربر و سبد خرید
    with open("products/templates/products/home.html", "r", encoding="utf-8") as f:
        home_content = f.read()
    
    # پیدا کردن نوار ناوبری و جایگزینی
    nav_start = home_content.find('<nav class="navbar navbar-expand-lg navbar-light bg-light">')
    nav_end = home_content.find('</nav>', nav_start) + 6
    
    new_navbar = '''    <!-- نوار ناوبری -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand sabla-logo" href="/">
                <span class="sabla-logo-icon">🌿</span>
                <span class="sabla-logo-text">سبلا</span>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="/">خانه</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/products/">محصولات</a>
                    </li>
                </ul>
                
                <div class="navbar-nav me-3">
                    {% if user.is_authenticated %}
                        <div class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <i class="bi bi-person-circle me-1"></i>
                                {{ user.first_name }} {{ user.last_name }}
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="/accounts/profile/">
                                    <i class="bi bi-person me-2"></i>پروفایل
                                </a></li>
                                <li><a class="dropdown-item" href="/accounts/orders/">
                                    <i class="bi bi-bag me-2"></i>سفارشات من
                                </a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <form method="post" action="/accounts/logout/" class="d-inline">
                                        {% csrf_token %}
                                        <button type="submit" class="dropdown-item border-0 bg-transparent">
                                            <i class="bi bi-box-arrow-left me-2"></i>خروج
                                        </button>
                                    </form>
                                </li>
                            </ul>
                        </div>
                        
                        <a class="nav-link position-relative" href="/cart/">
                            <i class="bi bi-cart3"></i>
                            سبد خرید
                            {% if user.cart.total_items > 0 %}
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                {{ user.cart.total_items }}
                            </span>
                            {% endif %}
                        </a>
                    {% else %}
                        <a class="nav-link" href="/accounts/login/">
                            <i class="bi bi-person me-1"></i>
                            ورود
                        </a>
                        <a class="nav-link" href="/accounts/signup/">
                            <i class="bi bi-person-plus me-1"></i>
                            ثبت نام
                        </a>
                    {% endif %}
                </div>
            </div>
        </div>
    </nav>'''
    
    home_content = home_content[:nav_start] + new_navbar + home_content[nav_end:]
    
    with open("products/templates/products/home.html", "w", encoding="utf-8") as f:
        f.write(home_content)
    print("✅ هدر با نام کاربر و سبد خرید به‌روزرسانی شد")
    
    # ۵. ایجاد template سبد خرید
    cart_html = '''<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سبد خرید - سبلا</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #2d5016;
            --secondary-color: #4a7c3a;
        }
        
        .cart-item {
            border: 1px solid #e9ecef;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
        }
        
        .quantity-btn {
            width: 35px;
            height: 35px;
            border: 1px solid #dee2e6;
            background: white;
            border-radius: 5px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .quantity-input {
            width: 50px;
            text-align: center;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            margin: 0 5px;
        }
        
        .summary-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 25px;
            position: sticky;
            top: 20px;
        }
    </style>
</head>
<body>
    {% include 'products/includes/header.html' %}

    <div class="container py-5">
        <div class="row">
            <div class="col-12">
                <h1 class="mb-4">سبد خرید</h1>
            </div>
        </div>

        {% if messages %}
            {% for message in messages %}
                <div class="alert alert-{{ message.tags }} alert-dismissible fade show" role="alert">
                    {{ message }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            {% endfor %}
        {% endif %}

        <div class="row">
            <!-- لیست محصولات -->
            <div class="col-lg-8">
                {% if cart.items.all %}
                    {% for item in cart.items.all %}
                    <div class="cart-item">
                        <div class="row align-items-center">
                            <div class="col-md-2">
                                <div class="bg-light rounded d-flex align-items-center justify-content-center" style="height: 80px;">
                                    <i class="bi bi-basket text-success fs-3"></i>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <h5 class="mb-1">{{ item.product.name }}</h5>
                                <p class="text-muted mb-0 small">{{ item.product.category.name }}</p>
                                {% if item.product.is_organic %}
                                <span class="badge bg-success">ارگانیک</span>
                                {% endif %}
                            </div>
                            <div class="col-md-3">
                                <div class="d-flex align-items-center">
                                    <form method="post" action="{% url 'update_cart_item' item.id %}">
                                        {% csrf_token %}
                                        <button type="submit" name="action" value="decrease" class="quantity-btn">-</button>
                                        <span class="quantity-input mx-2">{{ item.quantity }}</span>
                                        <button type="submit" name="action" value="increase" class="quantity-btn">+</button>
                                    </form>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <strong>{{ item.total_price|floatformat:0 }} تومان</strong>
                            </div>
                            <div class="col-md-1">
                                <form method="post" action="{% url 'update_cart_item' item.id %}">
                                    {% csrf_token %}
                                    <button type="submit" name="action" value="remove" class="btn btn-outline-danger btn-sm">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    {% endfor %}
                {% else %}
                    <div class="text-center py-5">
                        <i class="bi bi-cart-x display-1 text-muted mb-3"></i>
                        <h3 class="text-muted">سبد خرید شما خالی است</h3>
                        <p class="text-muted">می‌توانید از بین محصولات متنوع ما انتخاب کنید</p>
                        <a href="/products/" class="btn btn-success">مشاهده محصولات</a>
                    </div>
                {% endif %}
            </div>

            <!-- خلاصه سبد خرید -->
            {% if cart.items.all %}
            <div class="col-lg-4">
                <div class="summary-card">
                    <h4 class="mb-4">خلاصه سفارش</h4>
                    
                    <div class="d-flex justify-content-between mb-2">
                        <span>تعداد کالاها:</span>
                        <span>{{ cart.total_items }} عدد</span>
                    </div>
                    
                    <div class="d-flex justify-content-between mb-3">
                        <span>مبلغ کل:</span>
                        <span class="fw-bold">{{ cart.total_price|floatformat:0 }} تومان</span>
                    </div>
                    
                    <hr>
                    
                    <div class="d-flex justify-content-between mb-4 fs-5">
                        <strong>قابل پرداخت:</strong>
                        <strong class="text-success">{{ cart.total_price|floatformat:0 }} تومان</strong>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <a href="{% url 'checkout' %}" class="btn btn-success btn-lg">
                            <i class="bi bi-credit-card me-2"></i>
                            ادامه تسویه حساب
                        </a>
                        <a href="/products/" class="btn btn-outline-success">
                            ادامه خرید
                        </a>
                    </div>
                </div>
            </div>
            {% endif %}
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
'''
    
    os.makedirs("products/templates/products/includes", exist_ok=True)
    with open("products/templates/products/includes/header.html", "w", encoding="utf-8") as f:
        f.write(new_navbar)
    
    with open("products/templates/products/cart.html", "w", encoding="utf-8") as f:
        f.write(cart_html)
    print("✅ صفحه سبد خرید ایجاد شد")
    
    # ۶. ایجاد صفحه تسویه حساب
    checkout_html = '''<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسویه حساب - سبلا</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
</head>
<body>
    {% include 'products/includes/header.html' %}

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h3 class="mb-0">تسویه حساب</h3>
                    </div>
                    
                    <div class="card-body">
                        <!-- اطلاعات مشتری -->
                        <div class="mb-4">
                            <h5 class="text-success mb-3">اطلاعات تحویل</h5>
                            <div class="row">
                                <div class="col-md-6">
                                    <p><strong>تحویل گیرنده:</strong> {{ user.get_full_name }}</p>
                                    <p><strong>شماره تماس:</strong> {{ user.profile.phone }}</p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong>آدرس:</strong> {{ user.profile.address }}</p>
                                    <p><strong>شهر:</strong> {{ user.profile.city }}</p>
                                </div>
                            </div>
                        </div>

                        <hr>

                        <!-- خلاصه سفارش -->
                        <div class="mb-4">
                            <h5 class="text-success mb-3">خلاصه سفارش</h5>
                            {% for item in cart.items.all %}
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <div>
                                    <span>{{ item.product.name }}</span>
                                    <small class="text-muted">× {{ item.quantity }}</small>
                                </div>
                                <span>{{ item.total_price|floatformat:0 }} تومان</span>
                            </div>
                            {% endfor %}
                            
                            <hr>
                            
                            <div class="d-flex justify-content-between fs-5">
                                <strong>مبلغ قابل پرداخت:</strong>
                                <strong class="text-success">{{ cart.total_price|floatformat:0 }} تومان</strong>
                            </div>
                        </div>

                        <!-- روش پرداخت -->
                        <div class="mb-4">
                            <h5 class="text-success mb-3">روش پرداخت</h5>
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="radio" name="paymentMethod" id="online" checked>
                                <label class="form-check-label" for="online">
                                    پرداخت آنلاین
                                </label>
                            </div>
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="radio" name="paymentMethod" id="cash">
                                <label class="form-check-label" for="cash">
                                    پرداخت در محل
                                </label>
                            </div>
                        </div>

                        <!-- دکمه‌های action -->
                        <div class="d-grid gap-2 d-md-flex justify-content-md-between">
                            <a href="{% url 'cart_view' %}" class="btn btn-outline-secondary">
                                <i class="bi bi-arrow-right me-1"></i>
                                بازگشت به سبد خرید
                            </a>
                            <button class="btn btn-success btn-lg">
                                <i class="bi bi-credit-card me-2"></i>
                                پرداخت و ثبت سفارش
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
'''
    
    with open("products/templates/products/checkout.html", "w", encoding="utf-8") as f:
        f.write(checkout_html)
    print("✅ صفحه تسویه حساب ایجاد شد")
    
    print("🎉 ویژگی‌های جدید اضافه شدند!")
    print("\n🛒 امکانات اضافه شده:")
    print("   ✅ نمایش نام کاربر در هدر")
    print("   ✅ سبد خرید با قابلیت افزودن/حذف")
    print("   ✅ صفحه مشاهده سبد خرید")
    print("   ✅ صفحه تسویه حساب")
    print("   ✅ شمارنده تعداد محصولات در سبد خرید")

if __name__ == "__main__":
    add_shopping_features()