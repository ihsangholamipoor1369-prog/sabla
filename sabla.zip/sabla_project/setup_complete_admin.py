import os
import subprocess
import sys
from pathlib import Path

def setup_complete_admin():
    """اسکریپت کامل برای اضافه کردن محصولات به پنل ادمین"""
    
    # تنظیم مسیر پروژه
    project_path = Path("/home/ihsan/Desktop/sabla_project")
    os.chdir(project_path)
    
    print("🚀 شروع تنظیم کامل پنل ادمین...")
    print("=" * 50)
    
    # ۱. ایجاد مدل‌های محصولات
    print("📦 مرحله ۱: ایجاد مدل‌های محصولات...")
    
    products_models_content = '''from django.db import models
from django.urls import reverse

class Category(models.Model):
    name = models.CharField(max_length=100, verbose_name="نام دسته‌بندی")
    description = models.TextField(blank=True, verbose_name="توضیحات")
    image = models.ImageField(upload_to='categories/', blank=True, null=True, verbose_name="تصویر")
    is_active = models.BooleanField(default=True, verbose_name="فعال")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاریخ ایجاد")
    
    class Meta:
        verbose_name = "دسته‌بندی"
        verbose_name_plural = "دسته‌بندی‌ها"
        ordering = ['name']
    
    def __str__(self):
        return self.name

class Product(models.Model):
    name = models.CharField(max_length=200, verbose_name="نام محصول")
    description = models.TextField(verbose_name="توضیحات")
    price = models.DecimalField(max_digits=10, decimal_places=0, verbose_name="قیمت (تومان)")
    discounted_price = models.DecimalField(max_digits=10, decimal_places=0, blank=True, null=True, verbose_name="قیمت تخفیف‌خورده")
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='products', verbose_name="دسته‌بندی")
    image = models.ImageField(upload_to='products/', blank=True, null=True, verbose_name="تصویر اصلی")
    is_organic = models.BooleanField(default=True, verbose_name="ارگانیک")
    is_available = models.BooleanField(default=True, verbose_name="موجود")
    stock = models.PositiveIntegerField(default=0, verbose_name="موجودی")
    origin = models.CharField(max_length=100, default="سیستان و بلوچستان", verbose_name="منطقه تولید")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاریخ ایجاد")
    
    class Meta:
        verbose_name = "محصول"
        verbose_name_plural = "محصولات"
        ordering = ['-created_at']
    
    def __str__(self):
        return self.name
    
    def get_absolute_url(self):
        return reverse('product_detail', args=[str(self.id)])
'''
    
    with open("products/models.py", "w", encoding="utf-8") as f:
        f.write(products_models_content)
    print("✅ مدل‌های محصولات ایجاد شدند")
    
    # ۲. ایجاد فایل admin برای محصولات
    print("🛠️ مرحله ۲: ایجاد پنل ادمین محصولات...")
    
    products_admin_content = '''from django.contrib import admin
from .models import Category, Product

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'is_active', 'created_at']
    list_filter = ['is_active', 'created_at']
    search_fields = ['name', 'description']
    list_editable = ['is_active']
    
    fieldsets = (
        ('اطلاعات اصلی', {
            'fields': ('name', 'description', 'image')
        }),
        ('تنظیمات', {
            'fields': ('is_active',)
        }),
    )

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = [
        'name', 'category', 'price', 'discounted_price', 
        'is_organic', 'is_available', 'stock', 'created_at'
    ]
    list_filter = ['category', 'is_organic', 'is_available', 'created_at']
    search_fields = ['name', 'description', 'origin']
    list_editable = ['price', 'discounted_price', 'is_available', 'stock']
    
    fieldsets = (
        ('اطلاعات اصلی', {
            'fields': ('name', 'description', 'category')
        }),
        ('قیمت‌گذاری و موجودی', {
            'fields': ('price', 'discounted_price', 'stock')
        }),
        ('تصاویر', {
            'fields': ('image',)
        }),
        ('مشخصات فنی', {
            'fields': ('origin',)
        }),
        ('تنظیمات', {
            'fields': ('is_organic', 'is_available')
        }),
    )
'''
    
    with open("products/admin.py", "w", encoding="utf-8") as f:
        f.write(products_admin_content)
    print("✅ پنل ادمین محصولات ایجاد شد")
    
    # ۳. ایجاد migrations
    print("📝 مرحله ۳: ایجاد migrations...")
    try:
        result = subprocess.run([sys.executable, "manage.py", "makemigrations", "products"], 
                              capture_output=True, text=True)
        if result.returncode == 0:
            print("✅ Migrations ایجاد شد")
            print(result.stdout)
        else:
            print("⚠️ خطا در ایجاد migrations:")
            print(result.stderr)
    except Exception as e:
        print(f"⚠️ خطا در ایجاد migrations: {e}")
    
    # ۴. اعمال migrations
    print("🗃️ مرحله ۴: اعمال migrations به دیتابیس...")
    try:
        result = subprocess.run([sys.executable, "manage.py", "migrate"], 
                              capture_output=True, text=True)
        if result.returncode == 0:
            print("✅ Migrations اعمال شد")
            print(result.stdout)
        else:
            print("⚠️ خطا در اعمال migrations:")
            print(result.stderr)
    except Exception as e:
        print(f"⚠️ خطا در اعمال migrations: {e}")
    
    # ۵. ایجاد داده‌های نمونه با استفاده از shell
    print("🌱 مرحله ۵: ایجاد داده‌های نمونه...")
    
    shell_script = '''
from products.models import Category, Product

# پاک کردن داده‌های قدیمی (اختیاری)
Product.objects.all().delete()
Category.objects.all().delete()

# ایجاد دسته‌بندی‌های نمونه
categories_data = [
    {'name': 'خرما', 'description': 'انواع خرماهای ارگانیک سیستان و بلوچستان'},
    {'name': 'ادویه‌جات', 'description': 'ادویه‌های طبیعی و محلی'},
    {'name': 'گیاهان دارویی', 'description': 'گیاهان دارویی ارگانیک'},
    {'name': 'عسل طبیعی', 'description': 'عسل‌های ارگانیک و طبیعی'},
    {'name': 'حبوبات', 'description': 'حبوبات مرغوب و ارگانیک'},
]

categories = {}
for cat_data in categories_data:
    category = Category.objects.create(
        name=cat_data['name'],
        description=cat_data['description']
    )
    categories[cat_data['name']] = category
    print(f"دسته‌بندی ایجاد شد: {category.name}")

# ایجاد محصولات نمونه
products_data = [
    {
        'name': 'خرما مضافتی',
        'description': 'خرما مضافتی ارگانیک و تازه از نخلستان‌های سیستان',
        'price': 50000,
        'discounted_price': 45000,
        'category': categories['خرما'],
        'is_organic': True,
        'stock': 100,
        'origin': 'سیستان'
    },
    {
        'name': 'خرما پیارم',
        'description': 'خرما پیارم درجه یک با بافتی نرم و طعمی فوق‌العاده',
        'price': 75000,
        'discounted_price': 68000,
        'category': categories['خرما'],
        'is_organic': True,
        'stock': 75,
        'origin': 'بلوچستان'
    },
    {
        'name': 'زعفران اصل',
        'description': 'زعفران با کیفیت و مرغوب از مزارع سیستان',
        'price': 120000,
        'category': categories['ادویه‌جات'],
        'is_organic': True,
        'stock': 50,
        'origin': 'سیستان'
    },
    {
        'name': 'زردچوبه تازه',
        'description': 'زردچوبه تازه و معطر با خواص درمانی فراوان',
        'price': 30000,
        'category': categories['ادویه‌جات'],
        'is_organic': True,
        'stock': 80,
        'origin': 'بلوچستان'
    },
    {
        'name': 'عسل طبیعی کوهی',
        'description': 'عسل صد درصد طبیعی و ارگانیک از زنبورداران محلی',
        'price': 80000,
        'category': categories['عسل طبیعی'],
        'is_organic': True,
        'stock': 40,
        'origin': 'کوهستان‌های سیستان'
    },
]

for prod_data in products_data:
    product = Product.objects.create(
        name=prod_data['name'],
        description=prod_data['description'],
        price=prod_data['price'],
        discounted_price=prod_data.get('discounted_price'),
        category=prod_data['category'],
        is_organic=prod_data['is_organic'],
        stock=prod_data['stock'],
        origin=prod_data['origin']
    )
    print(f"محصول ایجاد شد: {product.name} - {product.price:,} تومان")

print("تعداد دسته‌بندی‌ها:", Category.objects.count())
print("تعداد محصولات:", Product.objects.count())
'''
    
    # اجرای اسکریپت در shell
    try:
        result = subprocess.run(
            [sys.executable, "manage.py", "shell", "-c", shell_script],
            capture_output=True, text=True
        )
        if result.returncode == 0:
            print("✅ داده‌های نمونه ایجاد شدند")
            print(result.stdout)
        else:
            print("⚠️ خطا در ایجاد داده‌های نمونه:")
            print(result.stderr)
    except Exception as e:
        print(f"⚠️ خطا در ایجاد داده‌های نمونه: {e}")
    
    # ۶. پیام نهایی
    print("=" * 50)
    print("🎉 تنظیم پنل ادمین با موفقیت کامل شد!")
    print("\n📋 آنچه انجام شد:")
    print("   ✅ مدل‌های Category و Product ایجاد شدند")
    print("   ✅ پنل ادمین برای محصولات تنظیم شد")
    print("   ✅ Migrations ایجاد و اعمال شد")
    print("   ✅ ۵ دسته‌بندی نمونه ایجاد شد")
    print("   ✅ ۵ محصول نمونه ایجاد شد")
    
    print("\n🌐 حالا می‌توانید:")
    print("   1. به پنل ادمین بروید: http://127.0.0.1:8000/admin/")
    print("   2. محصولات و دسته‌بندی‌ها را مدیریت کنید")
    print("   3. محصولات جدید اضافه کنید")
    
    print("\n🔧 اگر سرور در حال اجرا نیست:")
    print("   python manage.py runserver")
    
    print("\n🔍 برای بررسی:")
    print("   python manage.py shell -c \"from products.models import Category, Product; print(f'دسته‌بندی‌ها: {Category.objects.count()}'); print(f'محصولات: {Product.objects.count()}')\"")

if __name__ == "__main__":
    setup_complete_admin()