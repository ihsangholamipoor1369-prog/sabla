from django.contrib import admin
from .models import Category, Product

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'is_active', 'created_at']
    list_filter = ['is_active', 'created_at']
    search_fields = ['name', 'description']
    list_editable = ['is_active']
    
    fieldsets = (
        ('اطلاعات اصلی', {
            'fields': ('name', 'description', 'image')
        }),
        ('تنظیمات', {
            'fields': ('is_active',)
        }),
    )

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = [
        'name', 'category', 'price', 'discounted_price', 
        'is_organic', 'is_available', 'stock', 'created_at'
    ]
    list_filter = ['category', 'is_organic', 'is_available', 'created_at']
    search_fields = ['name', 'description', 'origin']
    list_editable = ['price', 'discounted_price', 'is_available', 'stock']
    
    fieldsets = (
        ('اطلاعات اصلی', {
            'fields': ('name', 'description', 'category')
        }),
        ('قیمت‌گذاری و موجودی', {
            'fields': ('price', 'discounted_price', 'stock')
        }),
        ('تصاویر', {
            'fields': ('image',)
        }),
        ('مشخصات فنی', {
            'fields': ('origin',)
        }),
        ('تنظیمات', {
            'fields': ('is_organic', 'is_available')
        }),
    )
