import os
import subprocess
import sys
from pathlib import Path

def fix_cart_migration():
    """رفع مشکل migrations سبد خرید"""
    
    project_path = Path("/home/ihsan/Desktop/sabla_project")
    os.chdir(project_path)
    
    print("🔧 رفع مشکل migrations سبد خرید...")
    
    # ۱. ایجاد migrations برای products
    print("📝 ایجاد migrations برای products...")
    result = subprocess.run([
        sys.executable, "manage.py", "makemigrations", "products"
    ], capture_output=True, text=True)
    
    if result.returncode == 0:
        print("✅ Migrations برای products ایجاد شد")
        if "No changes" not in result.stdout:
            print(result.stdout)
    else:
        print("⚠️ خطا در ایجاد migrations:")
        print(result.stderr)
        return
    
    # ۲. اعمال migrations
    print("🗃️ اعمال migrations...")
    result = subprocess.run([
        sys.executable, "manage.py", "migrate"
    ], capture_output=True, text=True)
    
    if result.returncode == 0:
        print("✅ تمام migrations اعمال شدند")
        print(result.stdout)
    else:
        print("⚠️ خطا در اعمال migrations:")
        print(result.stderr)
        return
    
    # ۳. بررسی وضعیت
    print("🔍 بررسی وضعیت دیتابیس...")
    result = subprocess.run([
        sys.executable, "manage.py", "showmigrations", "products"
    ], capture_output=True, text=True)
    
    if result.returncode == 0:
        print("📊 وضعیت migrations محصولات:")
        print(result.stdout)
    
    print("🎉 مشکل سبد خرید حل شد!")
    print("🔄 حالا می‌توانید از سبد خرید استفاده کنید")

if __name__ == "__main__":
    fix_cart_migration()