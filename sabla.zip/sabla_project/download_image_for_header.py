import os
from pathlib import Path

def improve_header_only():
    """زیباسازی هدر بدون دانلود تصاویر"""
    
    project_path = Path("/home/ihsan/Desktop/sabla_project")
    os.chdir(project_path)
    
    print("🎨 زیباسازی هدر...")
    
    # ایجاد پوشه‌های مورد نیاز
    os.makedirs("static/css", exist_ok=True)
    
    # ایجاد فایل CSS برای هدر زیبا
    header_css = '''/* استایل‌های هدر زیبا */
.header-premium {
    background: linear-gradient(135deg, #2d5016, #4a7c3a);
    background-size: cover;
    background-position: center;
    box-shadow: 0 4px 20px rgba(0,0,0,0.1);
}

.navbar-premium {
    background: rgba(255, 255, 255, 0.95) !important;
    backdrop-filter: blur(15px);
    border-bottom: 1px solid rgba(255, 255, 255, 0.2);
    box-shadow: 0 2px 30px rgba(0,0,0,0.1);
}

.navbar-brand-premium {
    font-weight: 800;
    font-size: 1.8rem;
    background: linear-gradient(135deg, #2d5016, #4a7c3a);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    display: flex;
    align-items: center;
    gap: 12px;
}

.logo-icon {
    width: 45px;
    height: 45px;
    background: linear-gradient(135deg, #2d5016, #4a7c3a);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
    font-size: 1.2rem;
    box-shadow: 0 4px 15px rgba(45, 80, 22, 0.3);
}

.nav-link-premium {
    font-weight: 600;
    color: #2d5016 !important;
    margin: 0 8px;
    padding: 8px 16px !important;
    border-radius: 25px;
    transition: all 0.3s ease;
}

.nav-link-premium:hover {
    background: linear-gradient(135deg, #2d5016, #4a7c3a);
    color: white !important;
    transform: translateY(-2px);
}

.nav-link-premium.active {
    background: linear-gradient(135deg, #2d5016, #4a7c3a);
    color: white !important;
}

.cart-badge {
    background: linear-gradient(135deg, #ff6b6b, #ee5a24);
    color: white;
    border-radius: 50%;
    width: 20px;
    height: 20px;
    font-size: 0.7rem;
    display: flex;
    align-items: center;
    justify-content: center;
    position: absolute;
    top: -5px;
    right: -5px;
}

.user-avatar {
    width: 40px;
    height: 40px;
    background: linear-gradient(135deg, #2d5016, #4a7c3a);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
}

/* انیمیشن‌ها */
@keyframes fadeInDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.navbar-premium {
    animation: fadeInDown 0.5s ease;
}

.hero-section-premium {
    background: linear-gradient(135deg, rgba(45, 80, 22, 0.9), rgba(74, 124, 58, 0.8));
    color: white;
    padding: 120px 0;
    text-align: center;
}

.hero-title {
    font-size: 3.5rem;
    font-weight: 800;
    margin-bottom: 1rem;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
}

.hero-subtitle {
    font-size: 1.3rem;
    margin-bottom: 2rem;
    opacity: 0.9;
}

.btn-hero {
    padding: 15px 30px;
    font-size: 1.1rem;
    border-radius: 50px;
    font-weight: 600;
    transition: all 0.3s ease;
}

.btn-hero:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
}

.stats-section {
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    border-radius: 20px;
    padding: 30px;
    margin-top: 50px;
}

.stat-item {
    text-align: center;
}

.stat-number {
    font-size: 2.5rem;
    font-weight: 800;
    margin-bottom: 0.5rem;
}

.stat-label {
    font-size: 0.9rem;
    opacity: 0.8;
}
'''
    
    with open("static/css/header.css", "w", encoding="utf-8") as f:
        f.write(header_css)
    print("✅ فایل CSS هدر ایجاد شد")
    
    print("🎉 هدر زیبا شد!")
    print("🔄 صفحه رو refresh کنید")

if __name__ == "__main__":
    improve_header_only()