import os
from pathlib import Path

def fix_cart_view():
    """رفع مشکل view سبد خرید"""
    
    project_path = Path("/home/ihsan/Desktop/sabla_project")
    os.chdir(project_path)
    
    print("🔧 رفع مشکل view سبد خرید...")
    
    # اصلاح view سبد خرید
    products_views_content = '''from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.contrib import messages
from .models import Product, Category, Cart, CartItem

def home_view(request):
    featured_products = Product.objects.filter(
        is_available=True,
        discounted_price__isnull=False
    )[:4]
    
    new_products = Product.objects.filter(is_available=True)[:8]
    categories = Category.objects.filter(is_active=True)[:6]
    organic_products = Product.objects.filter(
        is_available=True, 
        is_organic=True
    )[:6]
    
    return render(request, 'products/home.html', {
        'site_name': 'سبلا',
        'description': 'فروشگاه محصولات ارگانیک سیستان و بلوچستان',
        'featured_products': featured_products,
        'new_products': new_products,
        'categories': categories,
        'organic_products': organic_products
    })

def product_list_view(request):
    products = Product.objects.filter(is_available=True)
    categories = Category.objects.filter(is_active=True)
    
    category_id = request.GET.get('category')
    if category_id:
        products = products.filter(category_id=category_id)
    
    return render(request, 'products/product_list.html', {
        'products': products,
        'categories': categories
    })

def product_detail_view(request, pk):
    product = get_object_or_404(Product, pk=pk, is_available=True)
    related_products = Product.objects.filter(
        category=product.category,
        is_available=True
    ).exclude(id=product.id)[:4]
    
    return render(request, 'products/product_detail.html', {
        'product': product,
        'related_products': related_products
    })

@login_required
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id, is_available=True)
    
    # ایجاد سبد خرید اگر وجود نداشته باشد
    cart, created = Cart.objects.get_or_create(user=request.user)
    
    cart_item, created = CartItem.objects.get_or_create(
        cart=cart,
        product=product,
        defaults={'quantity': 1}
    )
    
    if not created:
        cart_item.quantity += 1
        cart_item.save()
    
    messages.success(request, f'{product.name} به سبد خرید اضافه شد')
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse({
            'success': True,
            'cart_total': cart.total_items,
            'message': f'{product.name} به سبد خرید اضافه شد'
        })
    
    return redirect('cart_view')

@login_required
def cart_view(request):
    # ایجاد یا دریافت سبد خرید کاربر
    cart, created = Cart.objects.get_or_create(user=request.user)
    return render(request, 'products/cart.html', {'cart': cart})

@login_required
def update_cart_item(request, item_id):
    cart_item = get_object_or_404(CartItem, id=item_id, cart__user=request.user)
    
    if request.method == 'POST':
        action = request.POST.get('action')
        
        if action == 'increase':
            cart_item.quantity += 1
        elif action == 'decrease' and cart_item.quantity > 1:
            cart_item.quantity -= 1
        elif action == 'remove':
            cart_item.delete()
            messages.success(request, 'محصول از سبد خرید حذف شد')
            return redirect('cart_view')
        
        cart_item.save()
    
    return redirect('cart_view')

@login_required
def checkout_view(request):
    # ایجاد یا دریافت سبد خرید کاربر
    cart, created = Cart.objects.get_or_create(user=request.user)
    
    if cart.total_items == 0:
        messages.warning(request, 'سبد خرید شما خالی است')
        return redirect('cart_view')
    
    return render(request, 'products/checkout.html', {
        'cart': cart,
        'user': request.user
    })
'''
    
    with open("products/views.py", "w", encoding="utf-8") as f:
        f.write(products_views_content)
    print("✅ view سبد خرید اصلاح شد")
    
    # همچنین template هدر رو اصلاح کنیم تا اگر سبد خرید وجود نداشت خطا ندهد
    with open("products/templates/products/includes/header.html", "r", encoding="utf-8") as f:
        header_content = f.read()
    
    # جایگزینی بخش سبد خرید در هدر
    old_cart_section = '''                        <a class="nav-link position-relative" href="/cart/">
                            <i class="bi bi-cart3"></i>
                            سبد خرید
                            {% if user.cart.total_items > 0 %}
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                {{ user.cart.total_items }}
                            </span>
                            {% endif %}
                        </a>'''
    
    new_cart_section = '''                        <a class="nav-link position-relative" href="/cart/">
                            <i class="bi bi-cart3"></i>
                            سبد خرید
                            {% if user.cart and user.cart.total_items > 0 %}
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                {{ user.cart.total_items }}
                            </span>
                            {% endif %}
                        </a>'''
    
    header_content = header_content.replace(old_cart_section, new_cart_section)
    
    with open("products/templates/products/includes/header.html", "w", encoding="utf-8") as f:
        f.write(header_content)
    print("✅ هدر اصلاح شد")
    
    print("🎉 مشکل سبد خرید حل شد!")
    print("🔄 حالا می‌توانید از سبد خرید استفاده کنید")

if __name__ == "__main__":
    fix_cart_view()