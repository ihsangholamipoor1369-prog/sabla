import os
from pathlib import Path

def fix_all_urls():
    """اصلاح تمام URLها"""
    
    project_path = Path("/home/ihsan/Desktop/sabla_project")
    os.chdir(project_path)
    
    print("🔧 اصلاح تمام URLها...")
    
    # ۱. اصلاح accounts/urls.py
    accounts_urls = '''from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('signup/', views.signup_view, name='signup'),
    path('login/', auth_views.LoginView.as_view(template_name='accounts/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('profile/', views.profile_view, name='profile'),
]
'''
    
    with open("accounts/urls.py", "w", encoding="utf-8") as f:
        f.write(accounts_urls)
    
    # ۲. اصلاح accounts/views.py
    accounts_views = '''from django.shortcuts import render

def signup_view(request):
    return render(request, 'accounts/signup.html')

def login_view(request):
    return render(request, 'accounts/login.html')

def profile_view(request):
    return render(request, 'accounts/profile.html')
'''
    
    with open("accounts/views.py", "w", encoding="utf-8") as f:
        f.write(accounts_views)
    
    # ۳. اصلاح sabla/urls.py (اگر نیاز باشد)
    with open("sabla/urls.py", "r", encoding="utf-8") as f:
        sabla_urls_content = f.read()
    
    # اگر accounts شامل نشده، اضافه کن
    if "path('accounts/', include('accounts.urls'))" not in sabla_urls_content:
        sabla_urls_content = sabla_urls_content.replace(
            "path('', include('products.urls')),",
            "path('', include('products.urls')),\n    path('accounts/', include('accounts.urls')),"
        )
        with open("sabla/urls.py", "w", encoding="utf-8") as f:
            f.write(sabla_urls_content)
    
    # ۴. ایجاد template لاگین مناسب
    login_html = '''<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ورود - سبلا</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="/">🌿 سبلا</a>
        </div>
    </nav>
    
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h3 class="mb-0">ورود به سبلا</h3>
                    </div>
                    <div class="card-body">
                        <form method="post">
                            {% csrf_token %}
                            <div class="mb-3">
                                <label class="form-label">نام کاربری</label>
                                <input type="text" name="username" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">رمز عبور</label>
                                <input type="password" name="password" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn-success w-100">ورود</button>
                        </form>
                        {% if form.errors %}
                        <div class="alert alert-danger mt-3">
                            نام کاربری یا رمز عبور اشتباه است.
                        </div>
                        {% endif %}
                        <div class="text-center mt-3">
                            <a href="/accounts/signup/">حساب ندارید؟ ثبت نام کنید</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
'''
    
    os.makedirs("accounts/templates/accounts", exist_ok=True)
    with open("accounts/templates/accounts/login.html", "w", encoding="utf-8") as f:
        f.write(login_html)
    
    print("✅ تمام URLها و templateها اصلاح شدند!")
    print("🔄 حالا سرور رو restart کنید و صفحه رو refresh کنید")

if __name__ == "__main__":
    fix_all_urls()