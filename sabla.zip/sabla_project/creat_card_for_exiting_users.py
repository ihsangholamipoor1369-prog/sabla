import os
import django
from pathlib import Path

def create_carts_for_existing_users():
    """ایجاد سبد خرید برای کاربران موجود"""
    
    project_path = Path("/home/ihsan/Desktop/sabla_project")
    os.chdir(project_path)
    
    print("🔧 ایجاد سبد خرید برای کاربران موجود...")
    
    # تنظیم Django
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'sabla.settings')
    django.setup()
    
    from django.contrib.auth.models import User
    from products.models import Cart
    
    # ایجاد سبد خرید برای همه کاربران
    users = User.objects.all()
    carts_created = 0
    
    for user in users:
        cart, created = Cart.objects.get_or_create(user=user)
        if created:
            carts_created += 1
            print(f"✅ سبد خرید برای {user.username} ایجاد شد")
        else:
            print(f"⚠️ سبد خرید برای {user.username} از قبل وجود داشت")
    
    print(f"🎉 تعداد سبدهای خرید ایجاد شده: {carts_created}")
    print(f"📊 تعداد کل کاربران: {users.count()}")

if __name__ == "__main__":
    create_carts_for_existing_users()