import os
from pathlib import Path

def fix_signup_issue():
    """رفع مشکل ثبت نام"""
    
    project_path = Path("/home/ihsan/Desktop/sabla_project")
    os.chdir(project_path)
    
    print("🔧 رفع مشکل ثبت نام...")
    
    # ۱. اصلاح فرم ثبت نام
    accounts_forms_content = '''from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import UserProfile

class CustomUserCreationForm(UserCreationForm):
    first_name = forms.CharField(
        max_length=30,
        required=True,
        label='نام',
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'نام خود را وارد کنید'
        })
    )
    last_name = forms.CharField(
        max_length=30,
        required=True,
        label='نام خانوادگی',
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'نام خانوادگی خود را وارد کنید'
        })
    )
    email = forms.EmailField(
        required=True,
        label='ایمیل',
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'placeholder': 'example@gmail.com'
        })
    )
    phone = forms.CharField(
        max_length=15,
        required=True,
        label='شماره تماس',
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '09xxxxxxxxx'
        })
    )
    address = forms.CharField(
        required=True,
        label='آدرس دقیق',
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 3,
            'placeholder': 'آدرس کامل خود را وارد کنید'
        })
    )
    city = forms.CharField(
        max_length=100,
        required=True,
        label='شهر',
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'نام شهر'
        })
    )
    postal_code = forms.CharField(
        max_length=10,
        required=True,
        label='کد پستی',
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'کد پستی ۱۰ رقمی'
        })
    )

    class Meta:
        model = User
        fields = ('first_name', 'last_name', 'email', 'username', 'password1', 'password2', 
                 'phone', 'address', 'city', 'postal_code')
        labels = {
            'username': 'نام کاربری',
            'password1': 'رمز عبور',
            'password2': 'تکرار رمز عبور',
        }
        widgets = {
            'username': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'نام کاربری دلخواه'
            }),
        }

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        
        if commit:
            user.save()
            # ایجاد پروفایل کاربر - فقط اگر وجود نداشته باشد
            profile, created = UserProfile.objects.get_or_create(
                user=user,
                defaults={
                    'phone': self.cleaned_data['phone'],
                    'address': self.cleaned_data['address'],
                    'city': self.cleaned_data['city'],
                    'postal_code': self.cleaned_data['postal_code']
                }
            )
            # اگر پروفایل از قبل وجود داشت، اطلاعات رو آپدیت کن
            if not created:
                profile.phone = self.cleaned_data['phone']
                profile.address = self.cleaned_data['address']
                profile.city = self.cleaned_data['city']
                profile.postal_code = self.cleaned_data['postal_code']
                profile.save()
        return user

class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['phone', 'address', 'city', 'postal_code']
        labels = {
            'phone': 'شماره تماس',
            'address': 'آدرس دقیق',
            'city': 'شهر',
            'postal_code': 'کد پستی',
        }
        widgets = {
            'phone': forms.TextInput(attrs={'class': 'form-control'}),
            'address': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'city': forms.TextInput(attrs={'class': 'form-control'}),
            'postal_code': forms.TextInput(attrs={'class': 'form-control'}),
        }

class UserUpdateForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email']
        labels = {
            'first_name': 'نام',
            'last_name': 'نام خانوادگی',
            'email': 'ایمیل',
        }
        widgets = {
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
        }
'''
    
    with open("accounts/forms.py", "w", encoding="utf-8") as f:
        f.write(accounts_forms_content)
    print("✅ فرم ثبت نام اصلاح شد")
    
    # ۲. اصلاح مدل برای غیرفعال کردن سیگنال‌های مشکل‌ساز
    accounts_models_content = '''from django.db import models
from django.contrib.auth.models import User

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    phone = models.CharField(max_length=15, verbose_name="شماره تماس")
    address = models.TextField(verbose_name="آدرس دقیق")
    city = models.CharField(max_length=100, verbose_name="شهر")
    postal_code = models.CharField(max_length=10, verbose_name="کد پستی")
    
    class Meta:
        verbose_name = "پروفایل کاربر"
        verbose_name_plural = "پروفایل‌های کاربران"
    
    def __str__(self):
        return f"پروفایل {self.user.get_full_name()}"

# سیگنال‌ها را موقتاً غیرفعال می‌کنیم تا مشکل duplicate حل شود
'''
    
    with open("accounts/models.py", "w", encoding="utf-8") as f:
        f.write(accounts_models_content)
    print("✅ مدل کاربر اصلاح شد")
    
    print("🎉 مشکل ثبت نام حل شد!")
    print("🔄 حالا ثبت نام کنید")

if __name__ == "__main__":
    fix_signup_issue()