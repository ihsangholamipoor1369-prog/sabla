import os
import shutil
from pathlib import Path

def final_fix():
    """اصلاح نهایی پروژه"""
    
    project_path = Path("/home/ihsan/Desktop/sabla_project")
    os.chdir(project_path)
    
    print("🔧 اصلاح نهایی پروژه...")
    
    # ۱. پاک کردن فایل‌های مشکل‌ساز
    urls_to_remove = [
        "products/urls.py",
        "products/views.py", 
        "accounts/urls.py",
        "accounts/views.py"
    ]
    
    for file_path in urls_to_remove:
        if Path(file_path).exists():
            os.remove(file_path)
            print(f"🗑️  حذف شد: {file_path}")
    
    # ۲. ایجاد products/views.py جدید
    products_views = '''from django.shortcuts import render
from django.http import HttpResponse

def home_view(request):
    return render(request, 'products/home.html', {
        'site_name': 'سبلا',
        'description': 'فروشگاه محصولات ارگانیک سیستان و بلوچستان'
    })
'''
    
    with open("products/views.py", "w", encoding="utf-8") as f:
        f.write(products_views)
    
    # ۳. ایجاد products/urls.py جدید
    products_urls = '''from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_view, name='home'),
]
'''
    
    with open("products/urls.py", "w", encoding="utf-8") as f:
        f.write(products_urls)
    
    # ۴. ایجاد accounts/views.py
    accounts_views = '''from django.shortcuts import render

def signup_view(request):
    return render(request, 'accounts/signup.html')

def login_view(request):
    return render(request, 'accounts/login.html')

def profile_view(request):
    return render(request, 'accounts/profile.html')
'''
    
    with open("accounts/views.py", "w", encoding="utf-8") as f:
        f.write(accounts_views)
    
    # ۵. ایجاد accounts/urls.py
    accounts_urls = '''from django.urls import path
from . import views

urlpatterns = [
    path('signup/', views.signup_view, name='signup'),
    path('login/', views.login_view, name='login'),
    path('profile/', views.profile_view, name='profile'),
]
'''
    
    with open("accounts/urls.py", "w", encoding="utf-8") as f:
        f.write(accounts_urls)
    
    # ۶. اصلاح sabla/urls.py
    main_urls = '''from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('products.urls')),
    path('accounts/', include('accounts.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
'''
    
    with open("sabla/urls.py", "w", encoding="utf-8") as f:
        f.write(main_urls)
    
    # ۷. ایجاد پوشه templates اگر وجود ندارد
    os.makedirs("products/templates/products", exist_ok=True)
    os.makedirs("accounts/templates/accounts", exist_ok=True)
    
    # ۸. ایجاد home.html
    home_html = '''<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سبلا - فروشگاه محصولات ارگانیک</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .hero-section {
            background: linear-gradient(135deg, #2d5016, #4a7c3a);
            color: white;
            padding: 100px 0;
            text-align: center;
        }
        .btn-sabla {
            background-color: #4a7c3a;
            border-color: #4a7c3a;
            color: white;
        }
        .btn-sabla:hover {
            background-color: #2d5016;
            border-color: #2d5016;
        }
        .feature-box {
            padding: 40px 20px;
            text-align: center;
            border-radius: 10px;
            margin: 20px 0;
            border: 1px solid #e9ecef;
        }
        .navbar-brand {
            color: #2d5016 !important;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <!-- نوار ناوبری -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="/">
                🌿 سبلا
            </a>
            <div class="navbar-nav">
                <a class="nav-link active" href="/">خانه</a>
                <a class="nav-link" href="/products/">محصولات</a>
                <a class="nav-link" href="/accounts/signup/">ثبت نام</a>
                <a class="nav-link" href="/accounts/login/">ورود</a>
            </div>
        </div>
    </nav>

    <!-- بخش اصلی -->
    <div class="hero-section">
        <div class="container">
            <h1 class="display-4">به سبلا خوش آمدید</h1>
            <p class="lead">فروشگاه محصولات ارگانیک و طبیعی سیستان و بلوچستان</p>
            <a href="/products/" class="btn btn-light btn-lg me-2">مشاهده محصولات</a>
            <a href="/accounts/signup/" class="btn btn-outline-light btn-lg">عضویت رایگان</a>
        </div>
    </div>

    <!-- ویژگی‌ها -->
    <div class="container py-5">
        <h2 class="text-center mb-5">چرا سبلا؟</h2>
        <div class="row">
            <div class="col-md-4">
                <div class="feature-box">
                    <h1>🌱</h1>
                    <h4>محصولات ارگانیک</h4>
                    <p>محصولات ۱۰۰% طبیعی و ارگانیک از مزارع بکر سیستان و بلوچستان</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-box">
                    <h1>🚚</h1>
                    <h4>تحویل سریع</h4>
                    <p>تحویل درب منزل در سراسر کشور با بسته‌بندی مناسب و بهداشتی</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-box">
                    <h1>⭐</h1>
                    <h4>کیفیت عالی</h4>
                    <p>ضمانت کیفیت و بازگشت وجه در صورت عدم رضایت از محصول</p>
                </div>
            </div>
        </div>
    </div>

    <!-- درباره ما -->
    <div class="bg-light py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h2>درباره سبلا</h2>
                    <p class="lead">
                        سبلا با هدف ارائه محصولات ارگانیک و طبیعی سیستان و بلوچستان 
                        تأسیس شده است. ما محصولات را مستقیماً از کشاورزان محلی 
                        خریداری کرده و با حفظ کیفیت به دست شما می‌رسانیم.
                    </p>
                    <a href="/about/" class="btn btn-sabla">بیشتر بدانید</a>
                </div>
                <div class="col-md-6 text-center">
                    <div style="font-size: 8rem;">🌿</div>
                </div>
            </div>
        </div>
    </div>

    <!-- پاورقی -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5>سبلا</h5>
                    <p>فروشگاه محصولات ارگانیک سیستان و بلوچستان</p>
                </div>
                <div class="col-md-6 text-end">
                    <p>تلفن: ۰۹۱۲ XXX XXXX</p>
                    <p>ایمیل: info@sabla.ir</p>
                </div>
            </div>
            <hr>
            <div class="text-center">
                <p>&copy; ۱۴۰۳ سبلا. تمام حقوق محفوظ است.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>'''
    
    with open("products/templates/products/home.html", "w", encoding="utf-8") as f:
        f.write(home_html)
    
    # ۹. ایجاد template ساده برای accounts
    signup_html = '''<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>ثبت نام - سبلا</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="/">🌿 سبلا</a>
        </div>
    </nav>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h3>ثبت نام در سبلا</h3>
                    </div>
                    <div class="card-body">
                        <p>سیستم ثبت نام به زودی فعال خواهد شد.</p>
                        <a href="/" class="btn btn-success">بازگشت به خانه</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>'''
    
    with open("accounts/templates/accounts/signup.html", "w", encoding="utf-8") as f:
        f.write(signup_html)
    
    login_html = '''<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>ورود - سبلا</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="/">🌿 سبلا</a>
        </div>
    </nav>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h3>ورود به سبلا</h3>
                    </div>
                    <div class="card-body">
                        <p>سیستم ورود به زودی فعال خواهد شد.</p>
                        <a href="/" class="btn btn-success">بازگشت به خانه</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>'''
    
    with open("accounts/templates/accounts/login.html", "w", encoding="utf-8") as f:
        f.write(login_html)
    
    print("✅ اصلاحات کامل انجام شد!")
    print("🔄 حالا سرور رو restart کنید")

if __name__ == "__main__":
    final_fix()