import os
import subprocess
import sys
from pathlib import Path

def fix_database():
    """ایجاد و اعمال migrations برای رفع خطای دیتابیس"""
    
    project_path = Path("/home/ihsan/Desktop/sabla_project")
    os.chdir(project_path)
    
    print("🔧 رفع خطای دیتابیس...")
    
    # ۱. ایجاد migrations برای accounts
    print("📝 ایجاد migrations برای accounts...")
    result = subprocess.run([
        sys.executable, "manage.py", "makemigrations", "accounts"
    ], capture_output=True, text=True)
    
    if result.returncode == 0:
        print("✅ Migrations برای accounts ایجاد شد")
        print(result.stdout)
    else:
        print("⚠️ خطا در ایجاد migrations:")
        print(result.stderr)
    
    # ۲. اعمال migrations
    print("🗃️ اعمال migrations به دیتابیس...")
    result = subprocess.run([
        sys.executable, "manage.py", "migrate"
    ], capture_output=True, text=True)
    
    if result.returncode == 0:
        print("✅ تمام migrations اعمال شدند")
        print(result.stdout)
    else:
        print("⚠️ خطا در اعمال migrations:")
        print(result.stderr)
    
    # ۳. بررسی وضعیت migrations
    print("🔍 بررسی وضعیت migrations...")
    result = subprocess.run([
        sys.executable, "manage.py", "showmigrations"
    ], capture_output=True, text=True)
    
    if result.returncode == 0:
        print("📊 وضعیت migrations:")
        print(result.stdout)
    
    print("🎉 مشکل دیتابیس حل شد!")
    print("🔄 حالا می‌توانید از سیستم ثبت نام استفاده کنید")

if __name__ == "__main__":
    fix_database()