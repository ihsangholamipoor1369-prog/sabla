import os
from pathlib import Path

def update_homepage():
    """به‌روزرسانی صفحه اصلی با نمایش محصولات"""
    
    project_path = Path("/home/ihsan/Desktop/sabla_project")
    os.chdir(project_path)
    
    print("🎨 به‌روزرسانی صفحه اصلی...")
    
    # ۱. به‌روزرسانی views.py برای نمایش محصولات
    products_views_content = '''from django.shortcuts import render
from .models import Product, Category

def home_view(request):
    # دریافت محصولات ویژه (دارای تخفیف)
    featured_products = Product.objects.filter(
        is_available=True,
        discounted_price__isnull=False
    )[:4]
    
    # دریافت جدیدترین محصولات
    new_products = Product.objects.filter(is_available=True)[:8]
    
    # دریافت دسته‌بندی‌ها
    categories = Category.objects.filter(is_active=True)[:6]
    
    # دریافت محصولات ارگانیک
    organic_products = Product.objects.filter(
        is_available=True, 
        is_organic=True
    )[:6]
    
    return render(request, 'products/home.html', {
        'site_name': 'سبلا',
        'description': 'فروشگاه محصولات ارگانیک سیستان و بلوچستان',
        'featured_products': featured_products,
        'new_products': new_products,
        'categories': categories,
        'organic_products': organic_products
    })
'''
    
    with open("products/views.py", "w", encoding="utf-8") as f:
        f.write(products_views_content)
    print("✅ views.py به‌روزرسانی شد")
    
    # ۲. ایجاد صفحه اصلی جدید با نمایش محصولات
    home_html_content = '''<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سبلا - فروشگاه محصولات ارگانیک</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #2d5016;
            --secondary-color: #4a7c3a;
            --accent-color: #8db596;
            --light-green: #e8f5e8;
        }
        
        .hero-section {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 100px 0;
            text-align: center;
        }
        
        .btn-sabla {
            background-color: var(--secondary-color);
            border-color: var(--secondary-color);
            color: white;
        }
        
        .btn-sabla:hover {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .product-card {
            border: 1px solid #e9ecef;
            border-radius: 10px;
            transition: all 0.3s ease;
            height: 100%;
        }
        
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        
        .product-image {
            height: 200px;
            background: linear-gradient(135deg, var(--light-green), #f8f9fa);
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 10px 10px 0 0;
            color: var(--secondary-color);
            font-size: 3rem;
        }
        
        .discount-badge {
            background: #dc3545;
            color: white;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: bold;
        }
        
        .organic-badge {
            background: var(--primary-color);
            color: white;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: bold;
        }
        
        .original-price {
            text-decoration: line-through;
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .category-card {
            background: white;
            border: 2px solid var(--light-green);
            border-radius: 10px;
            padding: 30px 20px;
            text-align: center;
            transition: all 0.3s ease;
            height: 100%;
        }
        
        .category-card:hover {
            border-color: var(--accent-color);
            transform: translateY(-3px);
        }
        
        .category-icon {
            font-size: 2.5rem;
            color: var(--primary-color);
            margin-bottom: 15px;
        }
        
        .section-title {
            color: var(--primary-color);
            position: relative;
            padding-bottom: 15px;
            margin-bottom: 30px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            right: 0;
            width: 60px;
            height: 3px;
            background: var(--accent-color);
        }
    </style>
</head>
<body>
    <!-- نوار ناوبری -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand fw-bold" href="/" style="color: var(--primary-color);">
                <i class="bi bi-flower1"></i>
                سبلا
            </a>
            <div class="navbar-nav">
                <a class="nav-link active" href="/">خانه</a>
                <a class="nav-link" href="/products/">محصولات</a>
                {% if user.is_authenticated %}
                    <a class="nav-link" href="/accounts/profile/">پروفایل</a>
                    <form method="post" action="/accounts/logout/" class="d-inline">
                        {% csrf_token %}
                        <button type="submit" class="btn btn-link nav-link">خروج</button>
                    </form>
                {% else %}
                    <a class="nav-link" href="/accounts/login/">ورود</a>
                    <a class="nav-link" href="/accounts/signup/">ثبت نام</a>
                {% endif %}
            </div>
        </div>
    </nav>

    <!-- بخش اصلی -->
    <div class="hero-section">
        <div class="container">
            <h1 class="display-4 fw-bold">به سبلا خوش آمدید</h1>
            <p class="lead">فروشگاه محصولات ارگانیک و طبیعی سیستان و بلوچستان</p>
            <a href="#products" class="btn btn-light btn-lg me-2">مشاهده محصولات</a>
            <a href="/accounts/signup/" class="btn btn-outline-light btn-lg">عضویت رایگان</a>
        </div>
    </div>

    <!-- دسته‌بندی‌ها -->
    <div class="container py-5">
        <h2 class="section-title text-center">دسته‌بندی محصولات</h2>
        <div class="row">
            {% for category in categories %}
            <div class="col-md-4 col-lg-2 mb-4">
                <div class="category-card">
                    <div class="category-icon">
                        <i class="bi bi-tags"></i>
                    </div>
                    <h5 class="fw-bold">{{ category.name }}</h5>
                    <p class="text-muted small">{{ category.description|truncatewords:5 }}</p>
                </div>
            </div>
            {% empty %}
            <div class="col-12 text-center">
                <p class="text-muted">هنوز دسته‌بندی‌ای ایجاد نشده است.</p>
            </div>
            {% endfor %}
        </div>
    </div>

    <!-- محصولات ویژه -->
    <div class="bg-light py-5">
        <div class="container">
            <h2 class="section-title text-center">محصولات ویژه</h2>
            <div class="row" id="products">
                {% for product in featured_products %}
                <div class="col-md-6 col-lg-3 mb-4">
                    <div class="product-card">
                        <div class="product-image">
                            <i class="bi bi-basket"></i>
                            {% if product.discounted_price %}
                            <span class="discount-badge position-absolute top-0 start-0 m-2">
                                تخفیف
                            </span>
                            {% endif %}
                            {% if product.is_organic %}
                            <span class="organic-badge position-absolute top-0 end-0 m-2">
                                ارگانیک
                            </span>
                            {% endif %}
                        </div>
                        <div class="card-body">
                            <h5 class="card-title fw-bold">{{ product.name }}</h5>
                            <p class="card-text text-muted small">{{ product.description|truncatewords:10 }}</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    {% if product.discounted_price %}
                                    <span class="original-price">{{ product.price|floatformat:0 }} تومان</span>
                                    <br>
                                    <span class="fw-bold text-success">{{ product.discounted_price|floatformat:0 }} تومان</span>
                                    {% else %}
                                    <span class="fw-bold text-dark">{{ product.price|floatformat:0 }} تومان</span>
                                    {% endif %}
                                </div>
                                <button class="btn btn-sabla btn-sm">
                                    <i class="bi bi-cart-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                {% empty %}
                <div class="col-12 text-center">
                    <p class="text-muted">هنوز محصول ویژه‌ای وجود ندارد.</p>
                </div>
                {% endfor %}
            </div>
        </div>
    </div>

    <!-- جدیدترین محصولات -->
    <div class="container py-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="section-title">جدیدترین محصولات</h2>
            <a href="/products/" class="btn btn-outline-sabla">مشاهده همه</a>
        </div>
        <div class="row">
            {% for product in new_products %}
            <div class="col-md-6 col-lg-3 mb-4">
                <div class="product-card">
                    <div class="product-image">
                        <i class="bi bi-gift"></i>
                        {% if product.is_organic %}
                        <span class="organic-badge position-absolute top-0 end-0 m-2">
                            ارگانیک
                        </span>
                        {% endif %}
                    </div>
                    <div class="card-body">
                        <h5 class="card-title fw-bold">{{ product.name }}</h5>
                        <p class="card-text text-muted small">{{ product.description|truncatewords:8 }}</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="fw-bold text-dark">{{ product.price|floatformat:0 }} تومان</span>
                            <button class="btn btn-sabla btn-sm">
                                <i class="bi bi-cart-plus"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            {% empty %}
            <div class="col-12 text-center">
                <p class="text-muted">هنوز محصولی ایجاد نشده است.</p>
            </div>
            {% endfor %}
        </div>
    </div>

    <!-- محصولات ارگانیک -->
    <div class="bg-light py-5">
        <div class="container">
            <h2 class="section-title text-center">محصولات ارگانیک</h2>
            <div class="row">
                {% for product in organic_products %}
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="product-card">
                        <div class="product-image">
                            <i class="bi bi-flower1"></i>
                            <span class="organic-badge position-absolute top-0 end-0 m-2">
                                ارگانیک
                            </span>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title fw-bold">{{ product.name }}</h5>
                            <p class="card-text text-muted">{{ product.description|truncatewords:12 }}</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="fw-bold text-success">{{ product.price|floatformat:0 }} تومان</span>
                                <div>
                                    <span class="badge bg-success me-2">{{ product.origin }}</span>
                                    <button class="btn btn-sabla btn-sm">
                                        <i class="bi bi-cart-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {% empty %}
                <div class="col-12 text-center">
                    <p class="text-muted">هنوز محصول ارگانیکی وجود ندارد.</p>
                </div>
                {% endfor %}
            </div>
        </div>
    </div>

    <!-- بخش انتخاب محصول -->
    <div class="container py-5">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h2 class="section-title">چگونه محصول انتخاب کنیم؟</h2>
                <div class="selection-steps">
                    <div class="d-flex align-items-center mb-4">
                        <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                            ۱
                        </div>
                        <div>
                            <h5 class="fw-bold mb-1">دسته‌بندی مورد نظر را انتخاب کنید</h5>
                            <p class="text-muted mb-0">از بین دسته‌بندی‌های مختلف محصول مورد نظر خود را پیدا کنید</p>
                        </div>
                    </div>
                    <div class="d-flex align-items-center mb-4">
                        <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                            ۲
                        </div>
                        <div>
                            <h5 class="fw-bold mb-1">محصول را بررسی کنید</h5>
                            <p class="text-muted mb-0">توضیحات، قیمت و مشخصات محصول را به دقت مطالعه کنید</p>
                        </div>
                    </div>
                    <div class="d-flex align-items-center mb-4">
                        <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                            ۳
                        </div>
                        <div>
                            <h5 class="fw-bold mb-1">به سبد خرید اضافه کنید</h5>
                            <p class="text-muted mb-0">با کلیک روی دکمه سبد خرید، محصول را به سفارش خود اضافه کنید</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 text-center">
                <div class="bg-light rounded p-5">
                    <i class="bi bi-hand-index display-1 text-primary mb-3"></i>
                    <h4>راهنمای انتخاب محصول</h4>
                    <p class="text-muted">برای انتخاب بهترین محصولات ارگانیک، راهنمای ما را مطالعه کنید</p>
                    <button class="btn btn-sabla">مشاهده راهنما</button>
                </div>
            </div>
        </div>
    </div>

    <!-- پاورقی -->
    <footer class="bg-dark text-white py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h5 class="fw-bold">سبلا</h5>
                    <p>فروشگاه محصولات ارگانیک و طبیعی سیستان و بلوچستان</p>
                    <div class="d-flex">
                        <a href="#" class="text-white me-3"><i class="bi bi-instagram fs-5"></i></a>
                        <a href="#" class="text-white me-3"><i class="bi bi-telegram fs-5"></i></a>
                        <a href="#" class="text-white"><i class="bi bi-whatsapp fs-5"></i></a>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <h5 class="fw-bold">دسترسی سریع</h5>
                    <div class="d-flex flex-column">
                        <a href="/" class="text-white-50 mb-2 text-decoration-none">خانه</a>
                        <a href="/products/" class="text-white-50 mb-2 text-decoration-none">محصولات</a>
                        <a href="/accounts/signup/" class="text-white-50 mb-2 text-decoration-none">ثبت نام</a>
                        <a href="/accounts/login/" class="text-white-50 mb-2 text-decoration-none">ورود</a>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <h5 class="fw-bold">تماس با ما</h5>
                    <p><i class="bi bi-geo-alt me-2"></i> سیستان و بلوچستان، ایران</p>
                    <p><i class="bi bi-phone me-2"></i> ۰۹۱۲ XXX XXXX</p>
                    <p><i class="bi bi-envelope me-2"></i> info@sabla.ir</p>
                </div>
            </div>
            <hr class="my-4">
            <div class="text-center">
                <p class="mb-0">&copy; ۱۴۰۳ سبلا. تمام حقوق محفوظ است.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // اسکریپت برای افزودن به سبد خرید
        document.addEventListener('DOMContentLoaded', function() {
            const addToCartButtons = document.querySelectorAll('.btn-sabla');
            
            addToCartButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const productCard = this.closest('.product-card');
                    const productName = productCard.querySelector('.card-title').textContent;
                    alert(`محصول "${productName}" به سبد خرید اضافه شد`);
                });
            });
        });
    </script>
</body>
</html>
'''
    
    with open("products/templates/products/home.html", "w", encoding="utf-8") as f:
        f.write(home_html_content)
    print("✅ صفحه اصلی به‌روزرسانی شد")
    
    # ۳. ایجاد صفحه محصولات (برای لینک "مشاهده همه")
    products_html_content = '''<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>همه محصولات - سبلا</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="/">🌿 سبلا</a>
        </div>
    </nav>
    
    <div class="container mt-5">
        <div class="row">
            <div class="col-12">
                <h1>همه محصولات</h1>
                <p class="text-muted">صفحه محصولات به زودی فعال خواهد شد</p>
                <a href="/" class="btn btn-success">بازگشت به خانه</a>
            </div>
        </div>
    </div>
</body>
</html>
'''
    
    # ایجاد پوشه و فایل محصولات اگر وجود ندارد
    os.makedirs("products/templates/products", exist_ok=True)
    with open("products/templates/products/product_list.html", "w", encoding="utf-8") as f:
        f.write(products_html_content)
    print("✅ صفحه محصولات ایجاد شد")
    
    print("🎉 صفحه اصلی با موفقیت به‌روزرسانی شد!")
    print("🌐 حالا صفحه رو refresh کنید")

if __name__ == "__main__":
    update_homepage()