import os
from pathlib import Path

def create_user_system():
    """ایجاد سیستم کاربری کامل با ثبت نام و مدیریت حساب"""
    
    project_path = Path("/home/ihsan/Desktop/sabla_project")
    os.chdir(project_path)
    
    print("👤 ایجاد سیستم کاربری کامل...")
    
    # ۱. به‌روزرسانی مدل کاربر
    accounts_models_content = '''from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    phone = models.CharField(max_length=15, verbose_name="شماره تماس")
    address = models.TextField(verbose_name="آدرس دقیق")
    city = models.CharField(max_length=100, verbose_name="شهر")
    postal_code = models.CharField(max_length=10, verbose_name="کد پستی")
    
    class Meta:
        verbose_name = "پروفایل کاربر"
        verbose_name_plural = "پروفایل‌های کاربران"
    
    def __str__(self):
        return f"پروفایل {self.user.get_full_name()}"

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    instance.profile.save()
'''
    
    with open("accounts/models.py", "w", encoding="utf-8") as f:
        f.write(accounts_models_content)
    print("✅ مدل کاربر به‌روزرسانی شد")
    
    # ۲. ایجاد فرم ثبت نام
    accounts_forms_content = '''from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import UserProfile

class CustomUserCreationForm(UserCreationForm):
    first_name = forms.CharField(
        max_length=30,
        required=True,
        label='نام',
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'نام خود را وارد کنید'
        })
    )
    last_name = forms.CharField(
        max_length=30,
        required=True,
        label='نام خانوادگی',
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'نام خانوادگی خود را وارد کنید'
        })
    )
    email = forms.EmailField(
        required=True,
        label='ایمیل',
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'placeholder': 'example@gmail.com'
        })
    )
    phone = forms.CharField(
        max_length=15,
        required=True,
        label='شماره تماس',
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '09xxxxxxxxx'
        })
    )
    address = forms.CharField(
        required=True,
        label='آدرس دقیق',
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 3,
            'placeholder': 'آدرس کامل خود را وارد کنید'
        })
    )
    city = forms.CharField(
        max_length=100,
        required=True,
        label='شهر',
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'نام شهر'
        })
    )
    postal_code = forms.CharField(
        max_length=10,
        required=True,
        label='کد پستی',
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'کد پستی ۱۰ رقمی'
        })
    )

    class Meta:
        model = User
        fields = ('first_name', 'last_name', 'email', 'username', 'password1', 'password2', 
                 'phone', 'address', 'city', 'postal_code')
        labels = {
            'username': 'نام کاربری',
            'password1': 'رمز عبور',
            'password2': 'تکرار رمز عبور',
        }
        widgets = {
            'username': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'نام کاربری دلخواه'
            }),
        }

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        
        if commit:
            user.save()
            # ایجاد پروفایل کاربر
            UserProfile.objects.create(
                user=user,
                phone=self.cleaned_data['phone'],
                address=self.cleaned_data['address'],
                city=self.cleaned_data['city'],
                postal_code=self.cleaned_data['postal_code']
            )
        return user

class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['phone', 'address', 'city', 'postal_code']
        labels = {
            'phone': 'شماره تماس',
            'address': 'آدرس دقیق',
            'city': 'شهر',
            'postal_code': 'کد پستی',
        }
        widgets = {
            'phone': forms.TextInput(attrs={'class': 'form-control'}),
            'address': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'city': forms.TextInput(attrs={'class': 'form-control'}),
            'postal_code': forms.TextInput(attrs={'class': 'form-control'}),
        }

class UserUpdateForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email']
        labels = {
            'first_name': 'نام',
            'last_name': 'نام خانوادگی',
            'email': 'ایمیل',
        }
        widgets = {
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
        }
'''
    
    with open("accounts/forms.py", "w", encoding="utf-8") as f:
        f.write(accounts_forms_content)
    print("✅ فرم‌های کاربر ایجاد شدند")
    
    # ۳. به‌روزرسانی views
    accounts_views_content = '''from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import CustomUserCreationForm, UserProfileForm, UserUpdateForm

def signup_view(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            
            # ورود خودکار کاربر بعد از ثبت نام
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            
            if user is not None:
                login(request, user)
                messages.success(request, 'ثبت نام با موفقیت انجام شد! به سبلا خوش آمدید.')
                return redirect('profile')
        else:
            messages.error(request, 'لطفاً خطاهای زیر را اصلاح کنید.')
    else:
        form = CustomUserCreationForm()
    
    return render(request, 'accounts/signup.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            messages.success(request, f'خوش آمدید {user.get_full_name()}!')
            return redirect('profile')
        else:
            messages.error(request, 'نام کاربری یا رمز عبور اشتباه است.')
    
    return render(request, 'accounts/login.html')

@login_required
def profile_view(request):
    return render(request, 'accounts/profile.html', {
        'user': request.user
    })

@login_required
def profile_edit_view(request):
    if request.method == 'POST':
        user_form = UserUpdateForm(request.POST, instance=request.user)
        profile_form = UserProfileForm(request.POST, instance=request.user.profile)
        
        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            messages.success(request, 'پروفایل شما با موفقیت به‌روزرسانی شد.')
            return redirect('profile')
        else:
            messages.error(request, 'لطفاً خطاهای زیر را اصلاح کنید.')
    else:
        user_form = UserUpdateForm(instance=request.user)
        profile_form = UserProfileForm(instance=request.user.profile)
    
    return render(request, 'accounts/profile_edit.html', {
        'user_form': user_form,
        'profile_form': profile_form
    })

@login_required
def order_history_view(request):
    # این صفحه بعداً با اطلاعات واقعی پر می‌شود
    return render(request, 'accounts/order_history.html')
'''
    
    with open("accounts/views.py", "w", encoding="utf-8") as f:
        f.write(accounts_views_content)
    print("✅ viewهای کاربر به‌روزرسانی شدند")
    
    # ۴. به‌روزرسانی URLs
    accounts_urls_content = '''from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('signup/', views.signup_view, name='signup'),
    path('login/', views.login_view, name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='/'), name='logout'),
    path('profile/', views.profile_view, name='profile'),
    path('profile/edit/', views.profile_edit_view, name='profile_edit'),
    path('orders/', views.order_history_view, name='order_history'),
]
'''
    
    with open("accounts/urls.py", "w", encoding="utf-8") as f:
        f.write(accounts_urls_content)
    print("✅ URLهای کاربر به‌روزرسانی شدند")
    
    # ۵. ایجاد template ثبت نام
    signup_html = '''<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ثبت نام - سبلا</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #2d5016;
            --secondary-color: #4a7c3a;
        }
        
        .register-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .register-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border-radius: 15px 15px 0 0 !important;
        }
        
        .btn-sabla {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            color: white;
        }
        
        .btn-sabla:hover {
            background: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
            color: white;
        }
        
        .form-section {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .section-title {
            color: var(--primary-color);
            border-right: 4px solid var(--secondary-color);
            padding-right: 10px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="/">
                <i class="bi bi-flower1 text-success"></i>
                سبلا
            </a>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card register-card">
                    <div class="card-header register-header text-center py-4">
                        <h2 class="mb-0">ثبت نام در سبلا</h2>
                        <p class="mb-0 opacity-75">فروشگاه محصولات ارگانیک سیستان و بلوچستان</p>
                    </div>
                    
                    <div class="card-body p-4">
                        {% if messages %}
                            {% for message in messages %}
                                <div class="alert alert-{{ message.tags }} alert-dismissible fade show" role="alert">
                                    {{ message }}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            {% endfor %}
                        {% endif %}

                        <form method="post" novalidate>
                            {% csrf_token %}
                            
                            <!-- اطلاعات شخصی -->
                            <div class="form-section">
                                <h4 class="section-title">
                                    <i class="bi bi-person me-2"></i>
                                    اطلاعات شخصی
                                </h4>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">نام</label>
                                        {{ form.first_name }}
                                        {% if form.first_name.errors %}
                                            <div class="text-danger small mt-1">{{ form.first_name.errors }}</div>
                                        {% endif %}
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">نام خانوادگی</label>
                                        {{ form.last_name }}
                                        {% if form.last_name.errors %}
                                            <div class="text-danger small mt-1">{{ form.last_name.errors }}</div>
                                        {% endif %}
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">ایمیل</label>
                                        {{ form.email }}
                                        {% if form.email.errors %}
                                            <div class="text-danger small mt-1">{{ form.email.errors }}</div>
                                        {% endif %}
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">شماره تماس</label>
                                        {{ form.phone }}
                                        {% if form.phone.errors %}
                                            <div class="text-danger small mt-1">{{ form.phone.errors }}</div>
                                        {% endif %}
                                    </div>
                                </div>
                            </div>

                            <!-- اطلاعات حساب کاربری -->
                            <div class="form-section">
                                <h4 class="section-title">
                                    <i class="bi bi-shield-lock me-2"></i>
                                    اطلاعات حساب کاربری
                                </h4>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">نام کاربری</label>
                                        {{ form.username }}
                                        {% if form.username.errors %}
                                            <div class="text-danger small mt-1">{{ form.username.errors }}</div>
                                        {% endif %}
                                        <div class="form-text">نام کاربری باید بین ۳ تا ۱۵۰ کاراکتر باشد</div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">رمز عبور</label>
                                        {{ form.password1 }}
                                        {% if form.password1.errors %}
                                            <div class="text-danger small mt-1">{{ form.password1.errors }}</div>
                                        {% endif %}
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">تکرار رمز عبور</label>
                                        {{ form.password2 }}
                                        {% if form.password2.errors %}
                                            <div class="text-danger small mt-1">{{ form.password2.errors }}</div>
                                        {% endif %}
                                    </div>
                                </div>
                            </div>

                            <!-- اطلاعات آدرس -->
                            <div class="form-section">
                                <h4 class="section-title">
                                    <i class="bi bi-geo-alt me-2"></i>
                                    اطلاعات آدرس
                                </h4>
                                <div class="mb-3">
                                    <label class="form-label">آدرس دقیق</label>
                                    {{ form.address }}
                                    {% if form.address.errors %}
                                        <div class="text-danger small mt-1">{{ form.address.errors }}</div>
                                    {% endif %}
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">شهر</label>
                                        {{ form.city }}
                                        {% if form.city.errors %}
                                            <div class="text-danger small mt-1">{{ form.city.errors }}</div>
                                        {% endif %}
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">کد پستی</label>
                                        {{ form.postal_code }}
                                        {% if form.postal_code.errors %}
                                            <div class="text-danger small mt-1">{{ form.postal_code.errors }}</div>
                                        {% endif %}
                                    </div>
                                </div>
                            </div>

                            <div class="d-grid">
                                <button type="submit" class="btn btn-sabla btn-lg py-3">
                                    <i class="bi bi-person-plus me-2"></i>
                                    ثبت نام و ایجاد حساب
                                </button>
                            </div>
                        </form>

                        <div class="text-center mt-4">
                            <p class="mb-0">قبلاً حساب کاربری دارید؟ 
                                <a href="{% url 'login' %}" class="text-success fw-bold">وارد شوید</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
'''
    
    with open("accounts/templates/accounts/signup.html", "w", encoding="utf-8") as f:
        f.write(signup_html)
    print("✅ صفحه ثبت نام ایجاد شد")
    
    # ۶. ایجاد صفحه مدیریت حساب
    profile_html = '''<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت حساب - سبلا</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #2d5016;
            --secondary-color: #4a7c3a;
        }
        
        .profile-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .sidebar {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border-radius: 15px;
            padding: 0;
        }
        
        .sidebar .nav-link {
            color: white;
            padding: 15px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link:hover {
            background: rgba(255,255,255,0.1);
        }
        
        .info-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="/">
                <i class="bi bi-flower1 text-success"></i>
                سبلا
            </a>
            <div class="navbar-nav">
                <a class="nav-link" href="/">بازگشت به سایت</a>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row">
            <!-- سایدبار -->
            <div class="col-md-3 mb-4">
                <div class="sidebar">
                    <div class="p-4 text-center">
                        <div class="bg-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" 
                             style="width: 80px; height: 80px;">
                            <i class="bi bi-person-fill text-success fs-2"></i>
                        </div>
                        <h5 class="mb-1">{{ user.get_full_name }}</h5>
                        <p class="mb-0 opacity-75">{{ user.username }}</p>
                    </div>
                    
                    <div class="nav flex-column">
                        <a class="nav-link active" href="{% url 'profile' %}">
                            <i class="bi bi-person me-2"></i>
                            اطلاعات حساب
                        </a>
                        <a class="nav-link" href="{% url 'profile_edit' %}">
                            <i class="bi bi-pencil me-2"></i>
                            ویرایش اطلاعات
                        </a>
                        <a class="nav-link" href="{% url 'order_history' %}">
                            <i class="bi bi-bag me-2"></i>
                            تاریخچه سفارشات
                        </a>
                        <a class="nav-link" href="{% url 'logout' %}">
                            <i class="bi bi-box-arrow-left me-2"></i>
                            خروج
                        </a>
                    </div>
                </div>
            </div>

            <!-- محتوای اصلی -->
            <div class="col-md-9">
                <div class="profile-card">
                    <div class="card-header bg-white">
                        <h3 class="mb-0">اطلاعات حساب کاربری</h3>
                    </div>
                    
                    <div class="card-body">
                        {% if messages %}
                            {% for message in messages %}
                                <div class="alert alert-{{ message.tags }} alert-dismissible fade show" role="alert">
                                    {{ message }}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            {% endfor %}
                        {% endif %}

                        <div class="row">
                            <!-- اطلاعات شخصی -->
                            <div class="col-md-6">
                                <div class="info-card">
                                    <h5 class="text-success mb-3">
                                        <i class="bi bi-person me-2"></i>
                                        اطلاعات شخصی
                                    </h5>
                                    <p><strong>نام کامل:</strong> {{ user.get_full_name }}</p>
                                    <p><strong>نام کاربری:</strong> {{ user.username }}</p>
                                    <p><strong>ایمیل:</strong> {{ user.email }}</p>
                                </div>
                            </div>

                            <!-- اطلاعات تماس -->
                            <div class="col-md-6">
                                <div class="info-card">
                                    <h5 class="text-success mb-3">
                                        <i class="bi bi-telephone me-2"></i>
                                        اطلاعات تماس
                                    </h5>
                                    <p><strong>شماره تماس:</strong> {{ user.profile.phone }}</p>
                                    <p><strong>شهر:</strong> {{ user.profile.city }}</p>
                                    <p><strong>کد پستی:</strong> {{ user.profile.postal_code }}</p>
                                </div>
                            </div>
                        </div>

                        <!-- آدرس -->
                        <div class="info-card">
                            <h5 class="text-success mb-3">
                                <i class="bi bi-geo-alt me-2"></i>
                                آدرس
                            </h5>
                            <p>{{ user.profile.address }}</p>
                        </div>

                        <!-- آمار سریع -->
                        <div class="row">
                            <div class="col-md-3">
                                <div class="card text-center border-0 bg-light">
                                    <div class="card-body">
                                        <i class="bi bi-bag text-success fs-1 mb-2"></i>
                                        <h4>۰</h4>
                                        <p class="mb-0 text-muted">سفارشات فعال</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card text-center border-0 bg-light">
                                    <div class="card-body">
                                        <i class="bi bi-clock-history text-success fs-1 mb-2"></i>
                                        <h4>۰</h4>
                                        <p class="mb-0 text-muted">سفارشات گذشته</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card text-center border-0 bg-light">
                                    <div class="card-body">
                                        <i class="bi bi-heart text-success fs-1 mb-2"></i>
                                        <h4>۰</h4>
                                        <p class="mb-0 text-muted">علاقه‌مندی‌ها</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card text-center border-0 bg-light">
                                    <div class="card-body">
                                        <i class="bi bi-star text-success fs-1 mb-2"></i>
                                        <h4>۰</h4>
                                        <p class="mb-0 text-muted">امتیاز شما</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="text-center mt-4">
                            <a href="{% url 'profile_edit' %}" class="btn btn-success me-2">
                                <i class="bi bi-pencil me-1"></i>
                                ویرایش اطلاعات
                            </a>
                            <a href="/" class="btn btn-outline-success">
                                <i class="bi bi-house me-1"></i>
                                بازگشت به سایت
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
'''
    
    with open("accounts/templates/accounts/profile.html", "w", encoding="utf-8") as f:
        f.write(profile_html)
    print("✅ صفحه مدیریت حساب ایجاد شد")
    
    # ۷. ایجاد صفحه ویرایش پروفایل
    profile_edit_html = '''<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ویرایش اطلاعات - سبلا</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
</head>
<body>
    <nav class="navbar navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="/">
                <i class="bi bi-flower1 text-success"></i>
                سبلا
            </a>
            <div class="navbar-nav">
                <a class="nav-link" href="{% url 'profile' %}">بازگشت به پروفایل</a>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h3 class="mb-0">ویرایش اطلاعات حساب</h3>
                    </div>
                    
                    <div class="card-body">
                        {% if messages %}
                            {% for message in messages %}
                                <div class="alert alert-{{ message.tags }} alert-dismissible fade show" role="alert">
                                    {{ message }}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            {% endfor %}
                        {% endif %}

                        <form method="post">
                            {% csrf_token %}
                            
                            <h5 class="text-success mb-3">اطلاعات شخصی</h5>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">نام</label>
                                    {{ user_form.first_name }}
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">نام خانوادگی</label>
                                    {{ user_form.last_name }}
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">ایمیل</label>
                                {{ user_form.email }}
                            </div>

                            <hr>
                            
                            <h5 class="text-success mb-3">اطلاعات تماس</h5>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">شماره تماس</label>
                                    {{ profile_form.phone }}
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">شهر</label>
                                    {{ profile_form.city }}
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12 mb-3">
                                    <label class="form-label">آدرس دقیق</label>
                                    {{ profile_form.address }}
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">کد پستی</label>
                                    {{ profile_form.postal_code }}
                                </div>
                            </div>

                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-success">
                                    <i class="bi bi-check-lg me-1"></i>
                                    ذخیره تغییرات
                                </button>
                                <a href="{% url 'profile' %}" class="btn btn-outline-secondary">
                                    <i class="bi bi-x me-1"></i>
                                    انصراف
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
'''
    
    with open("accounts/templates/accounts/profile_edit.html", "w", encoding="utf-8") as f:
        f.write(profile_edit_html)
    print("✅ صفحه ویرایش پروفایل ایجاد شد")
    
    # ۸. ایجاد صفحه تاریخچه سفارشات
    order_history_html = '''<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تاریخچه سفارشات - سبلا</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
</head>
<body>
    <nav class="navbar navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="/">
                <i class="bi bi-flower1 text-success"></i>
                سبلا
            </a>
            <div class="navbar-nav">
                <a class="nav-link" href="{% url 'profile' %}">بازگشت به پروفایل</a>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h3 class="mb-0">تاریخچه سفارشات</h3>
                    </div>
                    
                    <div class="card-body">
                        <div class="text-center py-5">
                            <i class="bi bi-bag-x display-1 text-muted mb-3"></i>
                            <h4 class="text-muted">هنوز سفارشی ثبت نکرده‌اید</h4>
                            <p class="text-muted">پس از ثبت اولین سفارش، تاریخچه آن در اینجا نمایش داده می‌شود</p>
                            <a href="/products/" class="btn btn-success">
                                <i class="bi bi-bag me-1"></i>
                                مشاهده محصولات
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
'''
    
    with open("accounts/templates/accounts/order_history.html", "w", encoding="utf-8") as f:
        f.write(order_history_html)
    print("✅ صفحه تاریخچه سفارشات ایجاد شد")
    
    print("🎉 سیستم کاربری کامل ایجاد شد!")
    print("\n🌐 آدرس‌های مهم:")
    print("   ثبت نام: http://127.0.0.1:8000/accounts/signup/")
    print("   مدیریت حساب: http://127.0.0.1:8000/accounts/profile/")
    print("   ویرایش اطلاعات: http://127.0.0.1:8000/accounts/profile/edit/")

if __name__ == "__main__":
    create_user_system()