import os
from pathlib import Path

def create_product_pages():
    """ایجاد صفحات محصولات"""
    
    project_path = Path("/home/ihsan/Desktop/sabla_project")
    os.chdir(project_path)
    
    print("📦 ایجاد صفحات محصولات...")
    
    # ایجاد صفحه لیست محصولات
    product_list_html = '''<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>محصولات - سبلا</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        .product-card {
            border: 1px solid #e9ecef;
            border-radius: 10px;
            transition: all 0.3s ease;
            height: 100%;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        .product-image {
            height: 200px;
            background: linear-gradient(135deg, #e8f5e8, #f8f9fa);
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 10px 10px 0 0;
            color: #4a7c3a;
            font-size: 3rem;
        }
    </style>
</head>
<body>
    {% include 'products/includes/header.html' %}

    <div class="container py-5">
        <h1 class="mb-4">همه محصولات</h1>
        
        <div class="row">
            {% for product in products %}
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="product-card">
                    <div class="product-image">
                        <i class="bi bi-basket"></i>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">{{ product.name }}</h5>
                        <p class="card-text text-muted small">{{ product.description|truncatewords:15 }}</p>
                        
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            {% if product.discounted_price %}
                                <span class="text-decoration-line-through text-muted">{{ product.price|floatformat:0 }} تومان</span>
                                <span class="fw-bold text-success">{{ product.discounted_price|floatformat:0 }} تومان</span>
                            {% else %}
                                <span class="fw-bold text-dark">{{ product.price|floatformat:0 }} تومان</span>
                            {% endif %}
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="badge bg-success">{{ product.category.name }}</span>
                            {% if product.is_organic %}
                            <span class="badge bg-primary">ارگانیک</span>
                            {% endif %}
                        </div>
                        
                        <form method="post" action="{% url 'add_to_cart' product.id %}" class="mt-3">
                            {% csrf_token %}
                            <button type="submit" class="btn btn-success w-100">
                                <i class="bi bi-cart-plus me-1"></i>
                                افزودن به سبد خرید
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            {% empty %}
            <div class="col-12 text-center py-5">
                <i class="bi bi-basket display-1 text-muted mb-3"></i>
                <h3 class="text-muted">هنوز محصولی وجود ندارد</h3>
                <p class="text-muted">محصولات به زودی اضافه خواهند شد</p>
            </div>
            {% endfor %}
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
'''
    
    with open("products/templates/products/product_list.html", "w", encoding="utf-8") as f:
        f.write(product_list_html)
    print("✅ صفحه لیست محصولات ایجاد شد")
    
    print("🎉 صفحات محصولات ایجاد شدند!")
    print("🌐 آدرس: http://127.0.0.1:8000/products/")

if __name__ == "__main__":
    create_product_pages()