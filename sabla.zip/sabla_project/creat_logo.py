import os
from pathlib import Path

def create_logo_files():
    """ایجاد فایل‌های لوگو و آیکون برای سبلا"""
    
    project_path = Path("/home/ihsan/Desktop/sabla_project")
    os.chdir(project_path)
    
    print("🎨 ایجاد لوگو و آیکون‌های سبلا...")
    
    # ایجاد پوشه‌های لازم
    os.makedirs("static/images", exist_ok=True)
    
    # ۱. ایجاد فایل CSS برای لوگوها
    logo_css = '''/* استایل‌های لوگو و آیکون‌های سبلا */
.sabla-logo {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    font-weight: bold;
    color: #2d5016;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 10px;
}

.sabla-logo-icon {
    font-size: 1.8rem;
    color: #4a7c3a;
}

.sabla-logo-text {
    font-size: 1.5rem;
    background: linear-gradient(135deg, #2d5016, #4a7c3a);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.logo-organic {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    background: linear-gradient(135deg, #2d5016, #4a7c3a);
    border-radius: 50%;
    color: white;
    font-weight: bold;
    font-size: 1.2rem;
}

.logo-leaf {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 45px;
    height: 45px;
    background: #2d5016;
    border-radius: 50% 50% 50% 0;
    transform: rotate(45deg);
    color: white;
    font-weight: bold;
    position: relative;
}

.logo-leaf::before {
    content: '🌿';
    transform: rotate(-45deg);
    display: block;
}

.logo-modern {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 42px;
    height: 42px;
    background: linear-gradient(135deg, #2d5016, #8db596);
    border-radius: 12px;
    color: white;
    font-weight: bold;
    font-size: 1.1rem;
    position: relative;
    overflow: hidden;
}

.logo-modern::before {
    content: 'س';
    position: relative;
    z-index: 2;
}

.logo-modern::after {
    content: '';
    position: absolute;
    top: -5px;
    right: -5px;
    width: 20px;
    height: 20px;
    background: rgba(255,255,255,0.2);
    border-radius: 50%;
}

/* استایل‌های مختلف برای لوگو */
.logo-version-1 {
    background: linear-gradient(135deg, #2d5016, #4a7c3a);
    padding: 8px 16px;
    border-radius: 25px;
    color: white;
    font-weight: bold;
    text-decoration: none;
}

.logo-version-2 {
    color: #2d5016;
    font-weight: bold;
    text-decoration: none;
    border: 2px solid #4a7c3a;
    padding: 6px 14px;
    border-radius: 20px;
}

.logo-version-3 {
    background: #e8f5e8;
    color: #2d5016;
    padding: 8px 16px;
    border-radius: 12px;
    font-weight: bold;
    text-decoration: none;
    border-left: 4px solid #4a7c3a;
}

.favicon {
    width: 32px;
    height: 32px;
    background: linear-gradient(135deg, #2d5016, #4a7c3a);
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 0.9rem;
    font-weight: bold;
}
'''
    
    with open("static/css/logo.css", "w", encoding="utf-8") as f:
        f.write(logo_css)
    print("✅ فایل CSS لوگو ایجاد شد")
    
    # ۲. ایجاد فایل HTML برای نمایش لوگوها
    logo_demo_html = '''<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوگوهای سبلا</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/static/css/logo.css">
    <style>
        .logo-preview {
            border: 1px solid #e9ecef;
            border-radius: 10px;
            padding: 30px;
            margin: 20px 0;
            text-align: center;
        }
        .logo-large {
            font-size: 3rem;
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <h1 class="text-center mb-5">لوگوهای طراحی شده برای سبلا</h1>
        
        <!-- لوگو ۱: ساده با آیکون -->
        <div class="logo-preview">
            <h3>لوگو ۱: ساده با آیکون</h3>
            <div class="logo-large mb-3">
                <a href="/" class="sabla-logo">
                    <span class="sabla-logo-icon">🌿</span>
                    <span class="sabla-logo-text">سبلا</span>
                </a>
            </div>
            <p class="text-muted">طراحی ساده و مدرن با آیکون گیاه</p>
        </div>
        
        <!-- لوگو ۲: دایره‌ای ارگانیک -->
        <div class="logo-preview">
            <h3>لوگو ۲: دایره‌ای ارگانیک</h3>
            <div class="logo-large mb-3">
                <a href="/" class="sabla-logo">
                    <span class="logo-organic">س</span>
                    <span class="sabla-logo-text">سبلا</span>
                </a>
            </div>
            <p class="text-muted">طرح دایره‌ای نماد محصولات ارگانیک</p>
        </div>
        
        <!-- لوگو ۳: برگ سبز -->
        <div class="logo-preview">
            <h3>لوگو ۳: برگ سبز</h3>
            <div class="logo-large mb-3">
                <a href="/" class="sabla-logo">
                    <span class="logo-leaf"></span>
                    <span class="sabla-logo-text">سبلا</span>
                </a>
            </div>
            <p class="text-muted">طرح برگ نماد طبیعت و رشد</p>
        </div>
        
        <!-- لوگو ۴: مدرن -->
        <div class="logo-preview">
            <h3>لوگو ۴: مدرن</h3>
            <div class="logo-large mb-3">
                <a href="/" class="sabla-logo">
                    <span class="logo-modern"></span>
                    <span class="sabla-logo-text">سبلا</span>
                </a>
            </div>
            <p class="text-muted">طراحی مدرن و مینیمال</p>
        </div>
        
        <!-- نسخه‌های مختلف -->
        <div class="row mt-5">
            <div class="col-md-4 mb-3">
                <div class="logo-preview">
                    <h5>نسخه ۱</h5>
                    <a href="/" class="logo-version-1">سبلا</a>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="logo-preview">
                    <h5>نسخه ۲</h5>
                    <a href="/" class="logo-version-2">سبلا</a>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="logo-preview">
                    <h5>نسخه ۳</h5>
                    <a href="/" class="logo-version-3">سبلا</a>
                </div>
            </div>
        </div>
        
        <!-- Favicon -->
        <div class="logo-preview">
            <h3>Favicon</h3>
            <div class="d-flex justify-content-center align-items-center gap-3">
                <div class="favicon">س</div>
                <div class="favicon">🌿</div>
                <div class="favicon" style="background: #2d5016;">س</div>
            </div>
        </div>
        
        <div class="text-center mt-5">
            <a href="/" class="btn btn-success">بازگشت به سایت</a>
        </div>
    </div>
</body>
</html>
'''
    
    with open("logo_demo.html", "w", encoding="utf-8") as f:
        f.write(logo_demo_html)
    print("✅ صفحه نمایش لوگوها ایجاد شد")
    
    # ۳. به‌روزرسانی صفحه اصلی با لوگوی جدید
    print("🔧 به‌روزرسانی صفحه اصلی با لوگوی جدید...")
    
    # خواندن فایل home.html فعلی
    with open("products/templates/products/home.html", "r", encoding="utf-8") as f:
        home_content = f.read()
    
    # جایگزینی نوار ناوبری با نسخه جدید دارای لوگو
    new_navbar = '''    <!-- نوار ناوبری -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand sabla-logo" href="/">
                <span class="sabla-logo-icon">🌿</span>
                <span class="sabla-logo-text">سبلا</span>
            </a>
            <div class="navbar-nav">
                <a class="nav-link active" href="/">خانه</a>
                <a class="nav-link" href="/products/">محصولات</a>
                {% if user.is_authenticated %}
                    <a class="nav-link" href="/accounts/profile/">پروفایل</a>
                    <form method="post" action="/accounts/logout/" class="d-inline">
                        {% csrf_token %}
                        <button type="submit" class="btn btn-link nav-link">خروج</button>
                    </form>
                {% else %}
                    <a class="nav-link" href="/accounts/login/">ورود</a>
                    <a class="nav-link" href="/accounts/signup/">ثبت نام</a>
                {% endif %}
            </div>
        </div>
    </nav>'''
    
    # پیدا کردن و جایگزینی نوار ناوبری قدیمی
    old_navbar_start = home_content.find('<!-- نوار ناوبری -->')
    old_navbar_end = home_content.find('</nav>', old_navbar_start) + 6
    
    if old_navbar_start != -1 and old_navbar_end != -1:
        home_content = home_content[:old_navbar_start] + new_navbar + home_content[old_navbar_end:]
        
        with open("products/templates/products/home.html", "w", encoding="utf-8") as f:
            f.write(home_content)
        print("✅ صفحه اصلی با لوگوی جدید به‌روزرسانی شد")
    
    # ۴. اضافه کردن لینک CSS لوگو به صفحه اصلی
    css_link = '<link rel="stylesheet" href="/static/css/logo.css">'
    if css_link not in home_content:
        # پیدا کردن تگ head و اضافه کردن لینک CSS
        head_end = home_content.find('</head>')
        if head_end != -1:
            home_content = home_content[:head_end] + f'\n    {css_link}' + home_content[head_end:]
            
            with open("products/templates/products/home.html", "w", encoding="utf-8") as f:
                f.write(home_content)
            print("✅ لینک CSS لوگو به صفحه اصلی اضافه شد")
    
    print("🎉 طراحی لوگو کامل شد!")
    print("\n🌐 می‌توانید لوگوها را در آدرس زیر مشاهده کنید:")
    print("   http://127.0.0.1:8000/logo_demo.html")
    print("\n📱 لوگو در صفحه اصلی سایت نیز به‌روزرسانی شد")

if __name__ == "__main__":
    create_logo_files()